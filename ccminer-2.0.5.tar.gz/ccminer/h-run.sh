#!/usr/bin/env bash
# ccminer implementation from https://github.com/minershive/hiveos-linux/tree/master/hive/miners/ccminer

source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME

[[ `ps aux | grep "./ccminer1" | grep -v grep | wc -l` != 0 ]] &&
	echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" &&
	exit 1

#try to release TIME_WAIT sockets
#while true; do
#	for con in `netstat -anp | grep TIME_WAIT | grep $MINER_API_PORT | awk '{print $5}'`; do
#		killcx $con lo
#	done
#	netstat -anp | grep TIME_WAIT | grep $MINER_API_PORT &&
#		continue ||
#		break
#done

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/hive/lib

CMDLINE=" -a rad -o $POOL -u $TEMPLATE $EXTRA"


if [[ ${PASS} =~ ^[0-9,\ ]+$ ]]; then
	count="$(nvtool -q --space --gpucount)"
	ARR=(${PASS//,/ })
	if [[ ${#ARR[@]} -gt 1 ]]; then
		cmd=""
		for(( i=0; i < count; i++)); do
			[[ -z ${ARR[i]} ]] && ARR[i]=${ARR[-1]}
			cmd+=" --index $i --setmem ${ARR[i]}"
		done
		./nvtool $cmd
	else
		./nvtool --setmem ${ARR[0]}
	fi
else
	./nvtool --setmem 0 >/dev/null
fi

if [[ -f /usr/lib/x86_64-linux-gnu/libcurl-compat.so.3.0.0 ]]; then
	LD_PRELOAD=libcurl-compat.so.3.0.0 ./ccminer -b 127.0.0.1:$MINER_API_PORT $CMDLINE 2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log
else
	./ccminer -b 127.0.0.1:$MINER_API_PORT $CMDLINE 2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log
fi

./nvtool --setmem 0 >/dev/null

