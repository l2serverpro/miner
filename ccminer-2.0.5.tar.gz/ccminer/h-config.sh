#!/usr/bin/env bash

conf=""
conf+="POOL=\"$CUSTOM_URL\""$'\n'
conf+="TEMPLATE=\"$CUSTOM_TEMPLATE\""$'\n'
conf+="EXTRA=\"$CUSTOM_USER_CONFIG\""$'\n'
conf+="PASS=\"$CUSTOM_PASS\""$'\n'

echo "$conf" > $CUSTOM_CONFIG_FILENAME
